from ...components.fundamental_component import FundamentalComponent

__all__ = [
    "DevToolsConnector",
]


class DevToolsConnector(FundamentalComponent):
    pass


DevToolsConnector._unique_id_ = "DevToolsConnector-builtin"

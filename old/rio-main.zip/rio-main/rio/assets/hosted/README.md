# Hosted Assets

**Any files in this directory are publicly hosted, WITHOUT ACCESS CONTROL.**

Use this to host assets such as JavaScript dependencies, fonts, etc. Just be
careful what you place here.

Yes, this file is also hosted.

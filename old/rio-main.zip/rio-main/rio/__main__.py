import rio.cli


def main():
    rio.cli.app.run()


if __name__ == "__main__":
    main()
